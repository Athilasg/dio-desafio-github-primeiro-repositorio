// Text below was written by Anthony Taylor, modified by David Calinski, revised for Aine by Nelson A. de Oliveira

There are several things to note with Aine.

- For AineL developers - if you use Creator in source/extras/creator,
  it will creates "new.aine" file which contains new patterns - it can
  be helpful in learning bot new things.

-There's really only 4 functions you need to use in any Aine interface:
   loadvars(filename);
   savevars(filesname);
   respond(text);
   initialize();

- a super simple program using Aine would be:

      initialize();
      loadvars(users_ip);
      while (user_is_still_talking_to_aine)
      {
        get_string(user_response);
        aines_answer = respond(user_response);
        print_out(aines_answer);
      }
      savevars(users_ip);  

- loadvars() and savevars() can have any file name,
  but for multiple users, you want a seperate var file for each user.
  So pick something unique. (IP address, user name, e-mail address, etc.).
  For single user applications - pick something static,
  such as loadvars("data/localhost.txt") and savevars("data/localhost.txt"). 

- There is a make file that should help compiling on unix systems.  Type 'make
  help' for details.

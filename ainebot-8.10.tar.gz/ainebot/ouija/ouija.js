var tdelay=10;
var cdelay=50;
function change_text(id,text) {
  if (!document.getElementById) {
 	document.all[id].innerHTML = text
 } else {
   var obj = document.getElementById(id);
	   obj.innerHTML=text;
 }
}

function add_text(id,text) {
  if (!document.getElementById) {
 	document.all[id].innerHTML += text
 } else {
   var obj = document.getElementById(id);
   obj.innerHTML+=text;
 }
}

function find_by_id(id) {
  if (!document.getElementById) {
 	return document.images[id]
 } else {
   return document.getElementById(id);
 }
}

var dragapproved=false
var z,x,y
function move_item(obj,x,y) 
{ 

//  change_text("outf",x+","+y);

  units="px";
     if (parseInt(navigator.appVersion) >= 5 || navigator.appVersion.indexOf["MSIE 5"] != -1) 
     { 
         obj.style.position = "absolute";
         obj.style.left = x + units; 
         obj.style.top = y + units; 
     } 
} 

var f,t
function myContext(evt)
{
evt = (evt) ? evt : ((window.event) ? window.event : "")
if (evt) 
{
	var elem
	if (evt.target) {
            elem = (evt.target.nodeType == 3) ? evt.target.parentNode : evt.target
        } else {
            elem = evt.srcElement
        }
        if (elem) {
	}
}
return false;
}
document.oncontextmenu = myContext;

var timerId=0;

function tset(tstr)
{
 tclear();
 eval(tstr);
 timerId=setTimeout('tset("'+tstr+'")',tdelay);
}

function tclear()
{
 if (timerId)
 {
 clearTimeout(timerId);
 timerId=0;
 }
}

function slow_spell_word(obj,x,y,word)
{
  tclear();

  var cx,cy;
  cx=parseInt(obj.style.left.replace(/px/g,""));
  cy=parseInt(obj.style.top.replace(/px/g,""));
  if (!cx)
	{
	cx=obj.style.pixelLeft;
	cy=obj.style.pixelTop;
	}
  nx=Math.round((cx+x)/2);
  ny=Math.round((cy+y)/2);
  if ((Math.abs(cx-nx)+Math.abs(cy-ny))< 5)
  {
  spell_word(obj,word);
  }
else
  {
   move_item(obj,nx,ny);
   timerId=setTimeout('slow_spell_word(find_by_id("'+obj.id+'"),'+x+','+y+',"'+word+'")',tdelay);
  }
}

function repeat_letter(obj,word)
{
  tclear();
  var cx,cy;
  cx=parseInt(obj.style.left.replace(/px/g,""));
  cy=parseInt(obj.style.top.replace(/px/g,""));
  if (!cx)
	{
	cx=obj.style.pixelLeft;
	cy=obj.style.pixelTop;
	}
  nx=cx+25;
  ny=cy-50;
  if ((Math.abs(cx-nx)+Math.abs(cy-ny))< 5)
  {
  spell_word(obj,word);
  }
else
  {
   move_item(obj,nx,ny);
   timerId=setTimeout('slow_spell_word(find_by_id("'+obj.id+'"),'+cx+','+cy+',"'+word+'")',tdelay);
  }
}

var lchar="";
function spell_word(obj,word)
{
  nchar=word.substring(0,1).toLowerCase();
  word=word.substring(1);
  if (!pos[nchar]&&(nchar.length>=1))
   { nchar=" ";}
/*
  while (!pos[nchar]&&(word.length>=1))
  {
  nchar=word.substring(0,1);
  word=word.substring(1);
  }
*/
  if (nchar.length==1)
  {
   add_text("outf",lchar);
   if (lchar==nchar)
   {
   lchar="";
   timerId=setTimeout('repeat_letter(find_by_id("'+obj.id+'"),"'+nchar+word+'")',cdelay);  
   }
 else
   {
   lchar=nchar;
   timerId=setTimeout('slow_spell_word(find_by_id("'+obj.id+'"),'+pos[nchar]+','+'"'+word+'")',cdelay);  
   }
  }
else
{ add_text("outf",lchar); }

}

var did=false;




// Letter Positions
var pos=new Array();
pos['a']="42,118";
pos['b']="73,96";
pos['c']="110,82";
pos['d']="142,71";
pos['e']="178,62";
pos['f']="208,62";
pos['g']="244,61";
pos['h']="279,59";
pos['i']="309,66";
pos['j']="328,76";
pos['k']="361,81";
pos['l']="391,92";
pos['m']="423,109";
pos['n']="54,161";
pos['o']="93,140";
pos['p']="121,128";
pos['q']="156,119";
pos['r']="186,112";
pos['s']="215,109";
pos['t']="238,108";
pos['u']="268,105";
pos['v']="305,110";
pos['w']="338,122";
pos['x']="374,136";
pos['y']="403,146";
pos['z']="429,167";
pos['1']="92,216";
pos['2']="124,217";
pos['3']="157,216";
pos['4']="190,217";
pos['5']="222,217";
pos['6']="255,217";
pos['7']="281,215";
pos['8']="317,217";
pos['9']="349,217";
pos['0']="380,217";
pos['yes']="77,-17";
pos['no']="408,-17";
pos['good bye']="244,289";
pos[' ']="239,164";


//testing
function drags(evt){
evt = (evt) ? evt : ((window.event) ? window.event : "")
if (evt) 
{
	var elem
	if (evt.target) {
            elem = (evt.target.nodeType == 3) ? evt.target.parentNode : evt.target
        } else {
            elem = evt.srcElement
        }
        if (elem) {
	            // process event here
		f=false;
		if (elem.className=="drag"){
			z=elem;
			f=true;
		}
		if (elem.className=="dragable"){
			z=elem;
			f=true;
		}
		if (f) {
		  //alert('hi')
			dragapproved=true
			if (!document.all)
			{
			  temp1=parseInt(z.style.left.replace(/px/g,""));
			  temp2=parseInt(z.style.top.replace(/px/g,""));
			  x=evt.clientX
			  y=evt.clientY
			} else {
			  temp1=z.style.pixelLeft
			  temp2=z.style.pixelTop
			  x=evt.clientX
			  y=evt.clientY
			}
			
			document.onmousemove=move
			document.onmouseup=dstop
        	}
    	}
}
}

function move(evt){
 evt = (evt) ? evt : ((window.event) ? window.event : "")	
	var button = evt.button ? evt.button == 1: true 
	if (dragapproved){
		w=temp1+evt.clientX-x
		h=temp2+evt.clientY-y
		move_item(z,w,h);
		return false
	}
}

function dstop(evt){
 evt = (evt) ? evt : ((window.event) ? window.event : "")
button = evt.button ? evt.button  == 1 : evt.which == 1 
if (button&&dragapproved)
 {
 dragapproved=false; 
 }
}


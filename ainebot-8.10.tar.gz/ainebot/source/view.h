/////////////////////////////////////////////////////////////////////////////
// Name:        view.h
// Purpose:     View classes
// Author:      Julian Smart
// Modified by: Philippe Raxhon
// Created:     04/01/98
// RCS-ID:      $Id: view.h,v 1.3 1999/02/16 20:16:15 JS Exp $
// Copyright:   (c) Julian Smart and Markus Holzem
// Licence:   	wxWindows license
/////////////////////////////////////////////////////////////////////////////

#ifdef __GNUG__
// #pragma interface
#endif

#ifndef _VIEW_H_
#define _VIEW_H_

#include "wx/docview.h"


class MyCanvas: public wxScrolledWindow
{
  public:
    wxView *view;
    
    MyCanvas(wxView *v, wxFrame *frame, const wxPoint& pos, const wxSize& size, const long style);
    virtual void OnDraw(wxDC& dc);
    void OnMouseEvent(wxMouseEvent& event);

DECLARE_EVENT_TABLE()
};



class MyAimlWindow: public wxTextCtrl
{
  public:
    wxView *view;
    
    MyAimlWindow(wxView *v, wxFrame *frame, const wxPoint& pos, const wxSize& size, const long style);
};


class DrawingView: public wxView
{
  DECLARE_DYNAMIC_CLASS(DrawingView)
 private:
 public:
  wxFrame *frame;
  MyCanvas *canvas;
  
  DrawingView(void) { canvas = (MyCanvas *) NULL; frame = (wxFrame *) NULL; };
  ~DrawingView(void) {};

  bool OnCreate(wxDocument *doc, long flags);
  void OnDraw(wxDC *dc);
  void OnUpdate(wxView *sender, wxObject *hint = (wxObject *) NULL);
  bool OnClose(bool deleteWindow = TRUE);

  void OnCut(wxCommandEvent& event);

DECLARE_EVENT_TABLE()
};



class AimlEditView: public wxView
{
	DECLARE_DYNAMIC_CLASS(AimlEditView)
	private:
	public:
		wxFrame *frame;
		MyAimlWindow *textsw;
  
		AimlEditView(): wxView() { frame = (wxFrame *) NULL; textsw = (MyAimlWindow *) NULL; }
		~AimlEditView(void) {}

		bool OnCreate(wxDocument *doc, long flags);
		void OnDraw(wxDC *dc);
		void OnUpdate(wxView *sender, wxObject *hint = (wxObject *) NULL);
		bool OnClose(bool deleteWindow = TRUE);
};



class MyTextWindow: public wxTextCtrl
{
  public:
    wxView *view;
    
    MyTextWindow(wxView *v, wxFrame *frame, const wxPoint& pos, const wxSize& size, const long style);
};

class TextEditView: public wxView
{
  DECLARE_DYNAMIC_CLASS(TextEditView)
 private:
 public:
  wxFrame *frame;
  MyTextWindow *textsw;
  
  TextEditView(): wxView() { frame = (wxFrame *) NULL; textsw = (MyTextWindow *) NULL; }
  ~TextEditView(void) {}

  bool OnCreate(wxDocument *doc, long flags);
  void OnDraw(wxDC *dc);
  void OnUpdate(wxView *sender, wxObject *hint = (wxObject *) NULL);
  bool OnClose(bool deleteWindow = TRUE);
};

#endif	//_VIEW_H_

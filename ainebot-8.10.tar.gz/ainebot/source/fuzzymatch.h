

#include "aine.h"


int fuzzymatch (char*, char*);
void spellchecker (char*);
void tokenizer (char*);


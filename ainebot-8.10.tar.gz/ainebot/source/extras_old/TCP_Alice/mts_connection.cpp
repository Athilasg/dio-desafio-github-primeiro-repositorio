/*
 * Daniel Myers
 * 3-30-2000
 * connection.cpp
 * Member functions for a thread-enabled socket connection class
 */

#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include "mts_connection.h"
#define _PTHREADS
#define _REENTRANT

Connection::Connection(int filehandle) //Class constructor
{
        fh = filehandle;
        pthread_mutex_init(&CxnMutex, NULL);
}
Connection::~Connection() //Class destructor
{
        pthread_mutex_lock(&CxnMutex);
        close(fh);
        pthread_mutex_unlock(&CxnMutex);
        pthread_mutex_destroy(&CxnMutex);
}                                         
void Connection::destroy() //Another way of calling the destructor
{
        this->~Connection();
}          

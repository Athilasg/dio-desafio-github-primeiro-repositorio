// ***************************************************************************
// *                                                                         *
// *   This program is free software; you can redistribute it and/or modify  *
// *   it under the terms of the GNU General Public License as published by  *
// *   the Free Software Foundation; either version 2 of the License, or     *
// *   (at your option) any later version.                                   * 
// *                                                                         *
// ***************************************************************************


// Whatever you do, please give credits to the author, jedi1@ig.com.br. Thanks


// This is a ultra-fast-hack (less than 1 hour).
// So don't expect it to solve all your problems.
// There is a LOT of things we could add, like the "distributed alice" concept
// a talking coke machine, cool :o)
// Mail me, I like them <jedi1@ig.com.br>

#include <iostream.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include "mts_server.h"
#include "mts_connection.h"
#include "c_alice.h"

//<start comment from: MTServer-0.30:example.ccp dmyers@pomona.edu>
//Note that max connetions refers to the number of threads running
//the handler function and not the maximum number of connections
//on hold (connections that have been processed by accept but are
//waiting for a free thread). </start :->
#define PORT 		1985
#define	MAX_CONNECTIONS	5
#define STATUS_DELAY	0
#define ALICE_WELCOME	"Welcome to TCP alice.\n" 
// we can use as a handshaking. like the client send the username ("localhost.txt")
// and the connection is kept open until the client closes it or some timeout
			
void AliceTCP(int, struct in_addr);

void AliceTCP(int fh, struct in_addr addr)
{
    char input[4096];
    char *alans = new char[4096];

    bzero(input, 4096);
//  send(fh, ALICE_WELCOME, strlen(ALICE_WELCOME), 0);
    recv(fh, input, 4096, 0);
    printf("sending to her brain: [%s]\n", input);
    alans = respond(input);
    stripurl(alans);
    send(fh, alans, strlen(alans), 0);
}

int main(void)
{
    Server srv;

    if(initialize("data/alice.ini"))
	 return(1);
    loadvars("log/localuser.txt");

    srv.StartServer(PORT, MAX_CONNECTIONS, STATUS_DELAY, "", AliceTCP);
    cout << "Alice TCP Server by <jedi1@ig.com.br>\n";
    cout << "Status: [online].\nPress any key to exit...\n";
    cin.get();
    savevars( "log/localuser.txt" );
    return 0;
}


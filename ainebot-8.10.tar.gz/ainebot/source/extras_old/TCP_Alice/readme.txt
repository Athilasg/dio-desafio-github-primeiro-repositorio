jedi1@ig.com.br
July 30, 2000

DESCRIPTION:
    TCP gateway to ALICE chatter robot (www.alicebot.com/org)
    It is multithreaded (someone want to stat its performance?)

USE:
    On the server containing the AIML, you run the TCP_Alice (the server)
    On Clients machine you run
    TCP_Client [-s hostname.org] [-p port] message to her
    And you will have a reply
    This is nice if you are plannig to add some gateways to alice's brain
    (like icq, webchat, pop, irc, web, etc) and/or create some nice GUI.
    The code contains exploitable portions, I'm a lousy programmer.
    Live with this or send me patches :)
 
INSTALL:
    tar zxvf tcp_alice.tgz -C /path/to/alice/source/C
    it contains a new Makefile, so watch out for overwriting.. 
    
FUTURE PLANS:
    I don't have time, but... [BOFH excuse #666]
    A distributed alice network sounds cool.
    It could search 
    1-the local_db for answers [if not]
    (2-send a query to a centralized server that will have all alice clones current online
    3-Search the query into server db [if not]
	(4-query others clients db)
    5-if got a reply add it to own db and send back to the origin.
    6-Them this query is added to local db.)
    
    Of course as the main server acts like a proxy it will sniff and add all
    new data to it's database. AIML propagating... :)
    Much like (I lied, it is waaaaaaaaaaaaaaaaay more simple) freenet.
    freenet.sourceforge.net
    
LICENSE:
    GPL. 
    BUT PLEASE include my contact email if you use the code :o)

NOTES:
    I'd very much appreciate any comments about this code. If you hate it,
    love it, downloaded it and forget about it, whatever, send me an
    e-mail at jedi1@ig.com.br.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef WIN32
	#include <winsock.h>
	#include <winbase.h>
#else
	#include <unistd.h>
	#include <netdb.h>
	#include <sys/socket.h>
	#include <netinet/in.h>
	#ifdef SUNOS
		#include <sys/varargs.h>
	#else
		#include <stdarg.h>
	#endif
#endif

struct node {
  char *s;
  node *next;
};

struct in_parsed {
  char sender[124];
  char reciever[24];
  char method[24];
  char answer[24];
  char sendnick[24];
  char sendip[254];
  char senduser[24];
  char text[512];
}; 

int writeit(int server, char *fmt, ...);
char* spacefixer(char *s,char b[1]);
int call_socket (char hostname[254], unsigned short portnum);
in_parsed parseold(char *s);

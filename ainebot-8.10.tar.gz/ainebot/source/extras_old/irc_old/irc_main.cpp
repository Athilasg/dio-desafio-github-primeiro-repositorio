#include "irc.h"
#include "alice.h"

int serv = -1;
in_parsed in;

//You must change the below to reflect your defaults.  

char nick[128] = "Alise";
char server[255] = "ced.dal.net";
char room[15] = "#Alicebot";
//note, you can put multiple rooms here.
int port = 6667; 


int main()
{
  initialize();
  //connect to server and cross fingers.
  char* var_file = new char[64];
  char* crap = new char[512];
  char* answer;
  if (!(serv = call_socket(server,port))){
    printf("Connection Failed, Exiting.\n");
    return(0);
  }
  writeit(serv,"PASS null\n");
#ifdef WIN32
  Sleep( (clock_t)2 * CLOCKS_PER_SEC );
#else
  sleep(2);
#endif
  writeit(serv,"NICK %s\n",nick);
#ifdef WIN32
  Sleep( (clock_t)2 * CLOCKS_PER_SEC );
#else
  sleep(2);
#endif
  writeit(serv,"USER blah blah@nowhere.com blah.com blah\n");
  memset(crap,0,512);
#ifdef WIN32
	recv (serv, crap, 512, 0);
#else
	read(serv,crap,512);
#endif
  if (strncmp(crap,"PING",4)==0) {
    crap=spacefixer(crap,":");
    writeit(serv,"PONG %s\n",crap);
  }
#ifdef WIN32
  Sleep( (clock_t)2 * CLOCKS_PER_SEC );
#else
  sleep(2);
#endif
  writeit(serv,"JOIN %s\n",room);
  while (42) {
    memset(answer,0,512);
    memset(crap,0,512);
	#ifdef WIN32
		if(recv(serv,crap,512,0) < 1){
	#else
    if(read(serv,crap,512) < 1){      
	#endif
      printf("Connection lost, exiting.\n");
      return (0);
    }
    if (strncmp(crap,"PING",4)==0) {
      crap=spacefixer(crap,":");
      writeit(serv,"PONG %s\n",crap);
    }
    in = parseold(crap);
    if (strncmp(in.method,"JOIN",4)==0){
      writeit(serv,"NOTICE %s :Hi, I don't like talking in channel, it's too noisy, but PM me!  Also if you could send one line at a time please. And none of those crazy actions.  Thanks.\n",in.sendnick);
    }
	#ifdef WIN32
    if ((strncmp(in.text,"\1",1)==0) && (_stricmp(in.reciever,nick)==0)){
	#else
    if ((strncmp(in.text,"\1",1)==0) && (strcasecmp(in.reciever,nick)==0)){
	#endif
      writeit(serv,"NOTICE %s :I can't recieve that type of message. Please type only plain PMs.  Also Please send one line at a time.\n",in.sendnick);
    }
    else {
		#ifdef WIN32
      if ( !_stricmp(in.reciever,nick) && !_stricmp(in.method,"PRIVMSG") && strncmp(in.sendnick,"\0",1)){
		#else
      if ( !strcasecmp(in.reciever,nick) && !strcasecmp(in.method,"PRIVMSG") && strncmp(in.sendnick,"\0",1)){
		#endif
        fflush(stdout);
        sprintf(var_file,"log/%s",in.sendnick);
        loadvars(var_file);
	printf("%s:%s\n",in.sendnick,in.text);
        answer = respond(in.text);
        stripurl(answer);
        printf("hippie:%s\n",answer);
        writeit(serv,"PRIVMSG %s :%s\n",in.sendnick,answer);
        savevars(var_file);
      }
    }
//  wipeparse();
  }
}

#include "irc.h"

int writeit(int server, char *fmt, ...)
{
  va_list va;
  char *buf = new char[512];
  va_start(va,fmt);
  vsprintf(buf,fmt,va);
  va_end(va);
#ifdef WIN32
  if (send(server,buf,strlen(buf),0) == -1)
#else  
  if (write(server,buf,strlen(buf)) == -1)
#endif
  {
    delete(buf);
    return(-1);
  }
  delete(buf);
  return(1);
}


char* spacefixer(char *s,char b[1]) 
{
  unsigned int i,j;
  for (i = 0, j = strcspn(s,b)+1; j <= strlen(s); i++, j++) s[i] = s[j];
  s[i+1]=0;
  return(s);
}

int call_socket (char hostname[254], unsigned short portnum)
{
  struct sockaddr_in sa;
  struct hostent *hp;
  int s;
  if ((hp = gethostbyname (hostname)) == NULL) {    return (-1);
  }
  memset(&sa, 0, sizeof (sa));
  memcpy((char *) &sa.sin_addr, hp->h_addr, hp->h_length);
  sa.sin_family = hp->h_addrtype;
  sa.sin_port = htons ((u_short) portnum);
  if ((s = socket (hp->h_addrtype, SOCK_STREAM, 0)) < 0)
    return (-1);
  if (connect (s, (struct sockaddr *) &sa, sizeof(sa)) < 0) {
	#ifdef WIN32
		closesocket (s);
	#else
		close (s);
	#endif
    return (-1);
  }
  return (s);
}

//ok, the plan is to use a linked list to store every word into an array
//of words, then make all these sender, reciever crap things, point to
//that array. 

in_parsed parseold(char *s)
{
  in_parsed a;
  memset(a.sender,0,124);
  memset(a.reciever,0,24);
  memset(a.method,0,24);
  memset(a.answer,0,24);
  memset(a.sendnick,0,24);
  memset(a.senduser,0,24);
  memset(a.sendip,0,254);
  memset(a.text,0,512);
  char* scrap = new char[512];
  memset(scrap,0,512);
  s = spacefixer(s,":");
  strncpy(a.sender,s,strcspn(s," "));
  scrap = a.sender;
  s = spacefixer(s," ");
  strncpy(a.method,s,strcspn(s," "));
  s = spacefixer(s," ");
  strncpy(a.reciever,s,strcspn(s," "));
  s = spacefixer(s," ");
  if (s[0] != ':'){
    strncpy(a.answer,s,strcspn(s,":"));
  }
  s = spacefixer(s,":");
  strncpy(a.text,s,strcspn(s,"\n"));
  if(strchr(scrap,'!')){
    strncpy(a.sendnick,scrap,strcspn(scrap,"!"));
    scrap = spacefixer(scrap,"!");
    strncpy(a.senduser,scrap,strcspn(scrap,"@"));
    scrap = spacefixer(scrap,"@");
    strncpy(a.sendip,scrap,strcspn(scrap,"\n"));
  }
  return(a);
}
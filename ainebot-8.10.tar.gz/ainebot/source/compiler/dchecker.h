#ifndef _DUPL_CHECKER_
#define _DUPL_CHECKER_

#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

void duplicate_checker (FILE *f, int binary);



#endif


void check_ainel (FILE *in);

#ifndef __AINE__
#define __AINE__

#define MAX_FILENAME_SIZE 128    /* max size a filename and path can be */
#define MAX_VARNAME_SIZE  25     /* max size the name of a var can be */
#define MAX_VARVAL_SIZE   128     /* max size the value of a var can be */
#define MAX_LINE_SIZE     16386  /* max size a line of text can be */
#define	MIN_LINE_SIZE	  1024   /* min size for a algetline */
#define MAX_RANDLIST_SIZE 200    /* max # of <l></l> in a random. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <locale.h>
#include <ctype.h>
#include "preproc.h"
#include "dchecker.h"
#include "checker.h"
#include "assert.h"
#include "../stuff.h"


#undef TRUE
#undef FALSE
typedef char Bool;
#define FALSE 0
#define TRUE 1

int dictionary (FILE *);
int save_dictionary (void);

#endif /* __AINE__ */

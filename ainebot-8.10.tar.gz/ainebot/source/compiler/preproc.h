/* preproc.h
   This is the header file for the preproccesor. */

#ifndef __PREPROC__
#define __PREPROC__

extern char *unsorted_a_scrap, *unsorted_d_scrap;


void panic (char*, ...);


/* checks to see if a file is around. */
int checkfile (char *filepath);


/* splits the aiml files into patterns.txt and templates.txt */
int prepare(void);

#endif /*__PREPROC__*/


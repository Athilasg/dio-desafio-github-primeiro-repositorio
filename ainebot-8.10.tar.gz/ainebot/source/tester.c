#include <ctype.h>
#include "aine.h"

/*
static int localchat(void)
{
	char input[512];
	char *output = (char*) malloc (sizeof(char) * 4096);
	char botname[32];
	char first[] = "CONNECT";
	if (initialize ("data/aine.ini"))
		return 1;
	loadvars ("log/localuser.txt");
	puts ("*  AINE v0.8.0 *");
	putchar ('\n');
	puts ("AINE, Open Source project, is based on:");
	puts ("\t* A.L.I.C.E. and AIML [http://alicebot.org] by Dr Richard S. Wallace");
	puts ("\t* C-Alice by Jacco Bikker");
	putchar ('\n');
	puts ("\tHome page: http://aine.szybkanauka.net\n");
	printf ("Loaded personality: %s.\n\n", getvar ("botname"));
	puts ("To shut down AINE, type \"exit\"\n");
	strcpy (botname, getvar ("botname"));
	*botname = toupper(*botname);
	strcpy (output, respond (first));
	stripurl (output);
	printf ("%s: %s\n", botname, output);
	putchar('>');
  
	while (1) {
		fgets (input, 512, stdin);
		spacetrim (input);
		if (!strn_case_cmp (input, "exit", 4) || !strn_case_cmp (input, "quit", 4) )
			break;
		else {
			printf ("\n%s: ", botname);
			strcpy (output, respond (input));
    	  		stripurl (output);
      			printf ("%s", output);
			printf ("\n>");
    		}
	}
	savevars ("log/localuser.txt");
	deinitialize();
	puts ("\nSee you next time!");
	free (output);
	return 0;
}
*/



// Place N random, alpha-numeric characters into the given
// buffer.  Assumes buf points to adequate storage.
//
// If the caller wants it null-terminated, he is responsible
// for that as well.

void str_rand (char * const buf, size_t const N) // orginal code by Skip Sopscak
{
	static char rbuf[sizeof(int)];
	static int j;
	int i = 0;
	while (i < N){
		if (j == 0)
			*(int*)rbuf = random()%256;
		if (isalnum (rbuf[j]) || ispunct (rbuf[j]) || isspace (rbuf[j]))
			buf[i++] = rbuf[j];
		j = (j + 1) % sizeof(int);
	}
}

void print_usage (char *s) {
	printf ("Aine tester, usage:\n");
	printf ("%s n\n", s);
	printf ("Where \"n\" is number of inputs/outputs\n");
	return;
}

int main (int argc, char* argv[])
{
	char *input = (char*) malloc (sizeof(char) * MAX_AINE_INPUT);
	char username[128];
	char *buf;
	int i, limit, z = 0;
	
	if (argc != 2) {
		print_usage(argv[0]);
		return 1;
	}
	
	limit = atoi (argv[1]);
	
	buf = (char*) malloc (sizeof(char) * MAX_OUTPUT);
	if (initialize ("data/aine.ini")) return 1;
	
	for (i = 0; i < limit; i++) {
		str_rand (input, random()%MAX_AINE_INPUT);
	//	printf ("input=[%s]\n", input);
		str_rand (username, random()%15 + 10);
		strcpy (buf, fullpath);
		strcat (buf, "log/users/");
		strcat (buf, username);
		loadvars (buf);
		z = 999;
		while (--z) {
			putchar ('.');
			strcpy (buf, respond (input));
			str_rand (input, random()%MAX_AINE_INPUT);
		}
		
		strcpy (buf, respond (input));
 		// stripurl (buf);
	//	printf ("output=[%s]\n", buf);
	//	fputs (buf, stdout);
		strcpy (buf, fullpath);
		strcat (buf, "log/users/");
		strcat (buf, username);
		savevars (buf);
		if (limit == 1)
			i--;
		putchar ('*');
	}
	deinitialize();
	free (buf);
	free (input);
	return (0);
}


/*  respond.h
    This file holds the functions for the responder. */


/* makes alice's answer pretty. (cleans up text) */
void print (void);
/* makes substitutions on text. */
void substitute(FILE *subst, char *text);
/* gets a response. */
char* respond2( char *text);

void reevaluate (char *line);

extern Bool eng;


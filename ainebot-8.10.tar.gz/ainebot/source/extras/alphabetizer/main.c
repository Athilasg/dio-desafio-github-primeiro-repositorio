/* (c) 2003 David Calinski 
   Fell free to use it, share, modify and redistribute under GNU GPL */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAX_LINE 8000

/* This program split your Aine file into sorted alphabetically Aine files.
 * ("A.aine" contains input beginning on "A", "B.aine" with inputs beginning with "B", etc.)
 * 
 * (if you have multiple Aine files, please merge them into one before using this program)
 */
   
/* To do: keep topic tags */

int main (void) {
	char c, t[MAX_LINE];
	FILE *f_in, *f_out;
	register short i, j;

	puts ("Make sure you have /dump directory ready\nShall I continue?");
	c = getchar();
	if (c == 'n' || c == 'N') return (0);
	
	while (1) {
		puts ("Ok. You should merge your .aine files into one I will sort.\n\
		    So, what is the name of file I should sort?");
		scanf ("%s", t);
		f_in = fopen (t, "r");
		if (!f_in) puts ("I cannot open this file.");
		else break;
	}

	puts ("Sorting. Stand by.");
	
	f_out = fopen ("dump/stars.aine", "w");
	if (!f_out) {
	    puts ("Fatal error: Cannot create a file in dump dir");
	    puts ("Please make sure you have permission to write there.");
	    exit (1);
	}
	while (!feof (f_in)) {
		for (i = '*'; i <= '_'; i++) {
			switch (i) {
				case '*': putchar ('*'); break;
				
				case '0':
					fclose (f_out);
					f_out = fopen ("dump/0.aine", "w"); break;
				case '1':
					fclose (f_out);
					f_out = fopen ("dump/1.aine", "w"); break;
				case '2':
					fclose (f_out);
					f_out = fopen ("dump/2.aine", "w"); break;
				case '3':
					fclose (f_out);
					f_out = fopen ("dump/3.aine", "w"); break;
				case '4':
					fclose (f_out);
					f_out = fopen ("dump/4.aine", "w"); break;
				case '5':
					fclose (f_out);
					f_out = fopen ("dump/5.aine", "w"); break;
				case '6':
					fclose (f_out);
					f_out = fopen ("dump/6.aine", "w"); break;
				case '7':
					fclose (f_out);
					f_out = fopen ("dump/7.aine", "w"); break;
				case '8':
					fclose (f_out);
					f_out = fopen ("dump/8.aine", "w"); break;
				case '9':
					fclose (f_out);
					f_out = fopen ("dump/9.aine", "w"); break;
				case 'A':
					putchar ('A');
					fclose (f_out);
					f_out = fopen ("dump/A.aine", "w"); break;
				case 'B':
					putchar ('B');
					fclose (f_out);
					f_out = fopen ("dump/B.aine", "w"); break;
				case 'C':
					putchar ('C');
					fclose (f_out);
					f_out = fopen ("dump/C.aine", "w"); break;
				case 'D':
					putchar ('D');
					fclose (f_out);
					f_out = fopen ("dump/D.aine", "w"); break;
				case 'E':
					putchar ('E');
					fclose (f_out);
					f_out = fopen ("dump/E.aine", "w"); break;
				case 'F':
					putchar ('F');
					fclose (f_out);
					f_out = fopen ("dump/F.aine", "w"); break;
				case 'G':
					putchar ('G');
					fclose (f_out);
					f_out = fopen ("dump/G.aine", "w"); break;
				case 'H':
					putchar ('H');
					fclose (f_out);
					f_out = fopen ("dump/H.aine", "w"); break;
				case 'I':
					putchar ('I');
					fclose (f_out);
					f_out = fopen ("dump/I.aine", "w"); break;
				case 'J':
					putchar ('J');
					fclose (f_out);
					f_out = fopen ("dump/J.aine", "w"); break;
				case 'K':
					putchar ('K');
					fclose (f_out);
					f_out = fopen ("dump/K.aine", "w"); break;
				case 'L':
					putchar ('L');
					fclose (f_out);
					f_out = fopen ("dump/L.aine", "w"); break;
				case 'M':
					putchar ('M');
					fclose (f_out);
					f_out = fopen ("dump/M.aine", "w"); break;
				case 'N':
					putchar ('N');
					fclose (f_out);
					f_out = fopen ("dump/N.aine", "w"); break;
				case 'O':
					putchar ('O');
					fclose (f_out);
					f_out = fopen ("dump/O.aine", "w"); break;
				case 'P':
					putchar ('P');
					fclose (f_out);
					f_out = fopen ("dump/P.aine", "w"); break;
				case 'Q':
					putchar ('Q');
					fclose (f_out);
					f_out = fopen ("dump/Q.aine", "w"); break;
				case 'R':
					putchar ('R');
					fclose (f_out);
					f_out = fopen ("dump/R.aine", "w"); break;
				case 'S':
					putchar ('S');
					fclose (f_out);
					f_out = fopen ("dump/S.aine", "w"); break;
				case 'T':
					putchar ('T');
					fclose (f_out);
					f_out = fopen ("dump/T.aine", "w"); break;
				case 'U':
					putchar ('U');
					fclose (f_out);
					f_out = fopen ("dump/U.aine", "w"); break;
				case 'V':
					putchar ('V');
					fclose (f_out);
					f_out = fopen ("dump/V.aine", "w"); break;
				case 'W':
					putchar ('W');
					fclose (f_out);
					f_out = fopen ("dump/W.aine", "w"); break;
				case 'X':
					putchar ('X');
					fclose (f_out);
					f_out = fopen ("dump/X.aine", "w"); break;
				case 'Y':
					putchar ('Y');
					fclose (f_out);
					f_out = fopen ("dump/Y.aine", "w"); break;
				case 'Z':
					putchar ('Z');
					fclose (f_out);
					f_out = fopen ("dump/Z.aine", "w"); break;
				case '_':
					putchar ('_');
					fclose (f_out);
					f_out = fopen ("dump/under.aine", "w"); break;
				default:
					fclose (f_out);
					f_out = fopen ("dump/huh.aine", "w"); break;
			}
			for (j = ' '; j <= '_'; j++) { 
/* ASCII numbers: ' ' (space) is on begginning, then others signs... numerals, alphabet, and then '_' */
				rewind (f_in);
				while (fgets (t, MAX_LINE, f_in)) {
					if (t[0] == '+' && t[1] == '[') {
						if (t[2] == i && t[3] == j)  {
							fprintf (f_out, t);
							fgets (t, MAX_LINE, f_in);
							fprintf (f_out, t);
							while (!strchr (t, ']')) {
								fgets (t, MAX_LINE, f_in);
								fprintf (f_out, t);
							}
							fprintf (f_out, "\n");
					}	}
				}
			}
		}
	}
	puts ("\nFile sorted with success!");
	return 0;
}

